package minersstudios.whomine.item.items;

import net.minecraft.item.DyeableItem;

public class DyeableHatItem extends HatItem implements DyeableItem {
    public DyeableHatItem(Settings settings) {
        super(settings);
    }
}
